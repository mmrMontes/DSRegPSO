import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pytictoc import TicToc
from cec2013lsgo.cec2013 import Benchmark

def GPSO(D,n,Ll,Lu,c1,c2,wmax,lambd,fevalmax,run,function,f):
    LSu = lambd*(Lu-Ll)
    LSl = -LSu
    X = np.random.uniform(Ll,Lu,(n,D))
    V = np.zeros(X.shape)
    C = np.array([f(X[i,:])for i in range(X.shape[0])])
    feval = n
    GPi = C
    Pi = X
    GBid = np.argmin(GPi)
    GB = GPi[GBid]
    PG = X[GBid]
    GB0 = GB
    it = 0
    GBlist = [[]]*int(fevalmax/n)
    GBlist[it] = GB 
    t = TicToc()
    t.tic()
    w = wmax
    while feval+n <= fevalmax:
        R1 = np.random.random(X.shape)
        R2 = np.random.random(X.shape)
        V = w*V+c1*R1*(PG-X)+c2*R2*(Pi-X)
        V = np.clip(V, LSl,LSu)
        X = X+V
        X = np.clip(X, Ll,Lu)
        C = np.array([f(X[i,:])for i in range(X.shape[0])])
        feval += n
        for i in range(n):
            if C[i]<GPi[i]:
                GPi[i]=C[i]
                Pi[i,:] = X[i,:]
                if GPi[i]<GB:
                    GB = GPi[i]
                    PG = Pi[i,:]
        it+=1
        
        if GB == 0:
            #print('Function:',function)
            #print('Iteration:',f"{it:.4E}")
            print("Function Evaluations: %f" % feval)
            print("Best Cost: %f" %GB)
            #print('Run:',run)
            #print('Time:',time)
            return GBlist,GB,PG
        GB0 = GB
        GBlist[it] = GB 
        if np.mod(feval,10000)==0:
            time = t.tocvalue()
            #print('Function:',function)
            #print('Iteration:',f"{it:.4E}")
            print("Function Evaluations: %f" % feval)
            print("Best Cost: %f" %GB)
            #print('Run:',run)
            #print('Time:',time)
            t.tic()
    return GBlist,GB,PG

if __name__ == '__main__':
    
    function = 1.0
    c1 = 1.0
    c2 = 1.0
    n = 1.0
    wmax = 1.0
    lambd = 1.0


   
    
    fevalmax = 5e5
    runs = 5
    np.random.seed(0)
    tt = TicToc()


    j = 0
    globalBestList = [] 
    itmax = int(fevalmax/n)##################################
    #tt.tic()
    while j<runs:
        bench = Benchmark()
        info = bench.get_info(int(function))
        f = bench.get_function(int(function))
        D = info['dimension']
        Lu = info['upper']
        Ll = info['lower']

        GBlist,GB1,X1 = GPSO(int(D),int(n),Ll,Lu,c1,c2,wmax,lambd,fevalmax,j+1,function,f)##########################
        del bench, info, f
        globalBestList.append(GB1)
        j+=1
    
        globalBestMean = np.mean(globalBestList)
        print("Mean Global Best: %f" % globalBestMean)
 
    
    #tt.toc()

#guild run GPSO function=[1.0] c1=[2.0] c2=[0.0] n=[60] wmax=[0.5] lambd=[0.6]
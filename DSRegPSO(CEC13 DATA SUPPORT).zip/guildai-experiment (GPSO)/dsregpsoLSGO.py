import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from pytictoc import TicToc
from cec2013lsgo.cec2013 import Benchmark

def DSRegPSO(D,n,Ll,Lu,c1,c2,Mmax,lambd,fdmax,fdmin,Smax,Smin,dseta,fevalmax,run,function,f):
    LSui = lambd*(Lu-Ll)
    LSu = LSui
    LSl = -LSu
    w = Mmax/2
    X = np.random.uniform(Ll,Lu,(n,D))
    V = np.zeros(X.shape)
    C = np.array([f(X[i,:])for i in range(X.shape[0])])
    feval = n
    GPi = C
    Pi = X
    GBid = np.argmin(GPi)
    GB = GPi[GBid]
    PG = X[GBid]
    GB0 = GB
    Ss = Smin
    deltamax = np.max(np.abs(PG))*fdmax
    deltamin = np.min(np.abs(PG))*fdmin
    delta = deltamin
    it = 0
    GBlist = [[]]*int(fevalmax/n)
    GBlist[it] = GB 
    t = TicToc()
    t.tic()
    while feval+n <= fevalmax:
        R1 = np.random.random(X.shape)
        R2 = np.random.random(X.shape)
        V = ((delta/deltamax)+(Ss/Smax))*w*V+c1*R1*(PG-X)+c2*R2*(Pi-X)
        V = np.clip(V, LSl,LSu)
        deltai = np.sum(np.absolute(X-PG),axis = 1)
        U = np.repeat((deltai < delta).reshape(n,1),D,axis = 1)
        psi = np.random.uniform(Ll,Lu,(n,D))
        X = (1-U)*(X+V)+U*psi
        X[X>Lu] = np.maximum(Ll,Lu+(Lu-X[X>Lu]))
        X[X<Ll] = np.minimum(Lu,Ll+Ll-X[X<Ll])
        X = np.clip(X, Ll,Lu)
        C = np.array([f(X[i,:])for i in range(X.shape[0])])
        feval += n
        for i in range(n):
            if C[i]<GPi[i]:
                GPi[i]=C[i]
                Pi[i,:] = X[i,:]
                if GPi[i]<GB:
                    GB = GPi[i]
                    PG = Pi[i,:]
        it+=1
        
        if GB == 0:
            #print('Function:',function)
            #print('Iteration:',f"{it:.4E}")
            print('Function Evaluations:', feval)
            print('Best Cost:', f"{GB:.4E}")
            #print('Run:',run)
            #print('Time:',time)
            return GBlist,GB,PG
        if np.absolute(GB-GB0)<=dseta*GB:
            if delta<deltamax:
                delta = delta+deltamax*Ss
            else:
                delta = deltamin
                if Ss>=Smax:
                    Ss = Smin
                else:
                    Ss = Ss+Smin        
        else:
            delta = deltamin
            Ss = Smin
        deltamax = np.max(np.abs(PG))*fdmax
        deltamin = np.min(np.abs(PG))*fdmin
        LSu = (((delta/deltamax)+(Ss/Smax))/2)*(LSui)
        LSl = -LSu
        GB0 = GB
        GBlist[it] = GB 
        if np.mod(feval,10000)==0:
            time = t.tocvalue()
            #print('Function:',function)
            #print('Iteration:',f"{it:.4E}")
            print('Function Evaluations:', feval)
            print('Best Cost:', f"{GB:.4E}")
            #print('Run:',run)
            #print('Time:',time)
       
           
            t.tic()
    return GBlist,GB,PG

if __name__ == '__main__':
    
    function = 1.0
    c1 = 1.0
    c2 = 1.0
    dseta = 1.0
    fdmax = 1.0
    fdmin = 1.0
    n = 1.0
    Mmax = 1.0
    lambd = 1.0
    Smax = 1.0
    Smin = 1.0

   
    
    fevalmax = 5e5
    runs = 5
    np.random.seed(0)
    tt = TicToc()


    j = 0
    globalBestList = [] 
    itmax = int(fevalmax/n)##################################
    #tt.tic()
    while j<runs:
        bench = Benchmark()
        info = bench.get_info(int(function))
        f = bench.get_function(int(function))
        D = info['dimension']
        Lu = info['upper']
        Ll = info['lower']

        GBlist,GB1,X1 = DSRegPSO(int(D),int(n),Ll,Lu,c1,c2,Mmax,lambd,fdmax,fdmin,
                        Smax,Smin,dseta,fevalmax,j+1,function,f)##########################
        del bench, info, f
        globalBestList.append(GB1)
        j+=1
    globalBestMean = np.mean(globalBestList)
    print('Mean Global Best:',globalBestMean)
    #tt.toc()

#guild run dsregpsoLSGO function=[1.0] c1=[2.0] c2=[0.0] dseta=[1e-5] fdmax=[1e-5] fdmin=[1e-5] n=[60] Mmax=[0.5] lambd=[0.6] Smax=[0.6] Smin=[0.06]
            
